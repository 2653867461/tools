# -*- coding: UTF-8 -*-

import re
import logging
import requests
import asyncio


'''
from shodan import Shodan
from bs4 import BeautifulSoup
from urllib.parse import quote
from playwright.async_api import async_playwright,Browser,Page,BrowserContext

'''

default_quake_token = "4621ca88-58e5-4dc6-b91b-a38c711310c0"
default_telegram_token = "7766598547:AAEL58ZZ27d3eIYUjKxuBzwNliEWs4UG5Ng"
default_shodan_token = "FwYffREcrkxi2etdqpiife0OnzDJwdEq"

'''

class search_engine:
    def __init__(self):
        self.pw = None
        self.browser : Browser = None
        self.context : BrowserContext = None 
        self.page :Page = None

    async def start(self):
        try:
            self.pw = await async_playwright().start()
            self.browser = await self.pw.chromium.launch(headless = True, args=['--disable-infobars','--start-maximized','--disable-blink-features=AutomationControlled','--ignore-certificate-errors'])
            self.context = await self.browser.new_context()
            self.page = await self.context.new_page()
            return True
               
        except Exception as e:
            logging.error(f"初始化流浏览器错误: {str(e)}")

        return False

    async def wait(self):
        await self.page.close()
        await self.context.close()
        await self.browser.close()
        await self.pw.stop()

    def _parse_bing_content(self,content):
        result = dict()

        try:
            soup = BeautifulSoup(content, features="lxml")
            for item in soup.find_all("li", class_="b_algo"):
                node = item.find("h2")
                link = node.a["href"] if node else None

                if link != None:
                    result[link] = "".join([string for string in node.stripped_strings])
        except Exception as e:
            logging.error(f"解析bing页面错误 当前页面: {self.page.url}")

        return result

    async def _goto_page(self,url:str):
        try:
            if not url.startswith("http"):
                url = "http://" + url

            response = await self.page.goto(url, wait_until="domcontentloaded")
            if response and response.ok:
                await self.page.evaluate("window.onload = function(){window.scrollTo(0, document.documentElement.scrollHeight)}")
                return True
            
        except Exception as e:
            logging.error(f"导航到指定页面错误: {url} - {str(e)}")

        return False

    async def _parse_search_next(self,location):
        try:
            pre_url = self.page.url

            #等待下一页按钮加载完成
            await self.page.wait_for_selector(location,timeout=30000)
            await self.page.click(location,timeout=30000)
            return pre_url != self.page.url
            
        except Exception as e:
            logging.error(f"获取下页失败 {e}\n")

        return False

    async def _search(self,url,parse_content,next_location,wait_location,limit=100):
        result = dict()
        times = 0

        if await self._goto_page(url) == True:

            while limit - len(result) > 0:
                try:
                    #等待页面加载完成
                    await self.page.wait_for_selector(wait_location,state="visible",timeout=30000)
                except Exception as e:
                    logging.error(f"等待页面加载超时")

                result.update(parse_content(await self.page.content()))

                if await self._parse_search_next(next_location):
                    times = times + 1
                else:
                    break

        logging.error("搜索结束 搜索内容：{}\t翻页次数：{}\t结果数量：{}".format(url, times, len(result)))
        return result

    async def bing_search(self,query,limit:int = 100):
        return await self._search("https://www.bing.com/search?q={}".format(quote(query)),self._parse_bing_content,'a[class="sb_pagN sb_pagN_bp b_widePag sb_bp "]','ol[id="b_results"]',limit)
    

async def bing_search(query,limit=100)->dict:
    result = {}
    engine = search_engine()
    if engine.start() == True:
        result = await engine.bing_search(query,limit)
        await engine.wait()
    return result
'''

class quake_engine:
    """
    字段	            类型	    必填	默认值	    备注
    pagination_id	    str	        否	    无	        分页id，指定分页id能够获取更多分页数据，分页id过期时间为5分钟
    query	            str	        是	    *	        查询语句
    rule	            str	        否	    无	        类型为IP列表的服务数据收藏名称
    ip_list	            List[str]	否	    无	        IP列表
    size	            int	        否	    10	        单次分页大小，分页大小越大，请求时间越长
    ignore_cache	    bool	    否	    false	    是否忽略缓存
    start_time	        str	        否	    无	        查询起始时间，接受2020-10-14 00:00:00格式的数据，时区为UTC
    end_time	        str	        否	    无	        查询截止时间，接受2020-10-14 00:00:00格式的数据，时区为UTC
    include	            List(str)	否	    无	        包含字段
    exclude	            List(str)	否	    无	        排除字段
    latest	            bool	    否	    false	    是否使用最新数据
    """

    def __init__(self, quake_token=default_quake_token) -> None:
        self.quake_header = {
            "X-QuakeToken": quake_token,
            "Content-Type": "application/json",
        }
        self.quake_token = quake_token
        self.status = "Successful"
        self.quake_url = {
            "service_spider": "https://quake.360.net/api/v3/scroll/quake_service",
            "host_spider": "https://quake.360.net/api/v3/scroll/quake_host",
        }

    def _quake_request_scroll(self, quake_url, quake_header, quake_param, **kwargs):
        result = None
        try:
            while True:
                result = requests.post(
                    quake_url, headers=quake_header, json=dict(**quake_param, **kwargs)
                ).json()

                self.status = result["message"]
                pagination_id = result["meta"].get("pagination_id", None)

                yield result["data"]
                if pagination_id == None or len(result["data"]) == 0:
                    break

                quake_param["pagination_id"] = pagination_id
        except Exception as error:
            logging.error("错误信息:{}\n".format(str(error)))

    def quake_service_spider(self, keyword, **kwargs):
        for items in self._quake_request_scroll(
            self.quake_url["service_spider"],
            self.quake_header,
            quake_param={"query": keyword, "latest": True},
            **kwargs
        ):
            for item in items:
                yield item

    def quake_host_spider(self, keyword, **kwargs):
        for items in self._quake_request_scroll(
            self.quake_url["host_spider"],
            self.quake_header,
            quake_param={"query": keyword, "latest": True},
            **kwargs
        ):
            for item in items:
                yield item


    def quake_get_service_Asset(self,keyword,**kwargs):
        result = set()
        quake_param = dict({"query": keyword, "latest": True}, **kwargs)
        while True:
            query_result = requests.post(self.quake_url["service_spider"], headers=self.quake_header, json=quake_param).json()

            self.status = query_result["message"]
            pagination_id = query_result["meta"].get("pagination_id", None)


            for item in query_result["data"]:
                if item.get("domain",None) != None:
                    result.add(item["domain"])
                elif item.get("ip",None) != None:
                    result.add(item["ip"])

            if pagination_id == None or len(query_result["data"]) == 0:
                break

            quake_param["pagination_id"] = pagination_id
        
        return result

'''

class shodan_engine:
    """
    {
        "matches": [
            {
                "product": "nginx",
                "hash": -1609083510,
                "ip": 1616761883,
                "org": "Comcast Business",
                "isp": "Comcast Business",
                "transport": "tcp",
                "cpe": [
                    "cpe:/a:igor_sysoev:nginx"
                ],
                "data": "HTTP/1.1 400 Bad Request\r\nServer: nginx\r\nDate: Mon, 25 Jan 2021 21:33:48 GMT\r\nContent-Type: text/html\r\nContent-Length: 650\r\nConnection: close\r\n\r\n",
                "asn": "AS7922",
                "port": 443,
                "hostnames": [
                    "three.webapplify.net"
                ],
                "location": {
                    "city": "Denver",
                    "region_code": "CO",
                    "area_code": null,
                    "longitude": -104.9078,
                    "country_code3": null,
                    "latitude": 39.7301,
                    "postal_code": null,
                    "dma_code": 751,
                    "country_code": "US",
                    "country_name": "United States"
                },
                "timestamp": "2021-01-25T21:33:49.154513",
                "domains": [
                    "webapplify.net"
                ],
                "http": {
                    "robots_hash": null,
                    "redirects": [],
                    "securitytxt": null,
                    "title": "400 The plain HTTP request was sent to HTTPS port",
                    "sitemap_hash": null,
                    "robots": null,
                    "server": "nginx",
                    "host": "96.93.212.27",
                    "html": "\r\n400 The plain HTTP request was sent to HTTPS port\r\n\r\n400 Bad Request\r\nThe plain HTTP request was sent to HTTPS port\r\nnginx\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n",
                    "location": "/",
                    "components": {},
                    "securitytxt_hash": null,
                    "sitemap": null,
                    "html_hash": 199333125
                },
                "os": null,
                "_shodan": {
                    "crawler": "c9b639b99e5410a46f656e1508a68f1e6e5d6f99",
                    "ptr": true,
                    "id": "534cc127-e734-44bc-be88-2e219a56a099",
                    "module": "auto",
                    "options": {}
                },
                "ip_str": "96.93.212.27"
            },
            {
                "product": "nginx",
                "hostnames": [
                    "kolobok.us"
                ],
                "hash": 1940048442,
                "ip": 3104568883,
                "org": "RuWeb",
                "isp": "RuWeb",
                "transport": "tcp",
                "cpe": [
                    "cpe:/a:igor_sysoev:nginx:1.4.2"
                ],
                "data": "HTTP/1.1 410 Gone\r\nServer: nginx/1.4.2\r\nDate: Mon, 25 Jan 2021 21:33:50 GMT\r\nContent-Type: text/html; charset=iso-8859-1\r\nContent-Length: 295\r\nConnection: keep-alive\r\n\r\n",
                "asn": "AS49189",
                "port": 80,
                "version": "1.4.2",
                "location": {
                    "city": null,
                    "region_code": null,
                    "area_code": null,
                    "longitude": 37.6068,
                    "country_code3": null,
                    "latitude": 55.7386,
                    "postal_code": null,
                    "dma_code": null,
                    "country_code": "RU",
                    "country_name": "Russia"
                },
                "timestamp": "2021-01-25T21:33:51.172037",
                "domains": [
                    "kolobok.us"
                ],
                "http": {
                    "robots_hash": null,
                    "redirects": [],
                    "securitytxt": null,
                    "title": "410 Gone",
                    "sitemap_hash": null,
                    "robots": null,
                    "server": "nginx/1.4.2",
                    "host": "185.11.246.51",
                    "html": "\n\n410 Gone\n\nGone\nThe requested resource/\nis no longer available on this server and there is no forwarding address.\nPlease remove all references to this resource.\n\n",
                    "location": "/",
                    "components": {},
                    "securitytxt_hash": null,
                    "sitemap": null,
                    "html_hash": 922034037
                },
                "os": null,
                "_shodan": {
                    "crawler": "c9b639b99e5410a46f656e1508a68f1e6e5d6f99",
                    "ptr": true,
                    "id": "118b7360-01d0-4edb-8ee9-01e411c23e60",
                    "module": "auto",
                    "options": {}
                },
                "ip_str": "185.11.246.51"
            },
            ...
        ],
        "facets": {
            "country": [
                {
                    "count": 7883733,
                    "value": "US"
                },
                {
                    "count": 2964965,
                    "value": "CN"
                },
                {
                    "count": 1945369,
                    "value": "DE"
                },
                {
                    "count": 1717359,
                    "value": "HK"
                },
                {
                    "count": 940900,
                    "value": "FR"
                }
            ]
        },
        "total": 23047224
    }
    """

    def __init__(self, shodan_token=default_shodan_token, proxies=default_proxy) -> None:
        self.shodan_token = shodan_token
        self.shodan_client = Shodan(shodan_token)

    def shodan_spider(self, keyword):
        for item in self.shodan_client.search_cursor(keyword):
            yield item

'''