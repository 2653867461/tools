import socket
import socks

from stem import Signal
from stem.control import Controller

default_proxy = None

def enable_v2ray_proxy():
    global default_proxy
    socks.set_default_proxy(socks.SOCKS5, "127.0.0.1", 10808)
    default_proxy = socket.socket
    socket.socket = socks.socksocket

def enable_qihoo_proxy():
    global default_proxy
    socks.set_default_proxy(socks.HTTP, "10.16.13.18", 8080)
    default_proxy = socket.socket
    socket.socket = socks.socksocket

def enable_tor_proxy():
    global default_proxy
    socks.set_default_proxy(socks.SOCKS5, "127.0.0.1", 9050)
    default_proxy = socket.socket
    socket.socket = socks.socksocket 

def tor_switch_proxy():
    with Controller.from_port(port=9051) as controller:
        controller.authenticate()
        controller.signal(Signal.NEWNYM)

