import requests
import json

def search_github_vpn_projects(): 
    url = "https://api.github.com/search/repositories"
    
    # 构造搜索关键词（可根据需求调整关键词）
    query = "免费订阅地址"
    
    # 设置请求头和参数
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Python/3.10",  # GitHub要求明确User-Agent
        "Accept": "application/vnd.github.v3+json"
    }
    params = {
        "q": query,
        "sort": "stars",  # 按星标排序
        "order": "desc",  # 降序排列
        "per_page": 100,    # 每页结果数（最大100）
        "type": "repositories",
        "page":"1"
    }

    try:
        response = requests.get(url, headers=headers, params=params)
        response.raise_for_status()  # 检查HTTP错误

        data = response.json()
        results = []
        
        for item in data.get("items", []):
            project_info = {
                "name": item.get("name", ""),
                "url": item.get("html_url", ""),
                "description": item.get("description", "") or "No description"  # 处理空描述
            }
            results.append(project_info)
        
        # 将结果保存到JSON文件
        with open("github_vpn_projects.json", "w", encoding="utf-8") as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
        
        print(f"找到 {len(results)} 个项目，结果已保存到 github_vpn_projects.json")
        return results

    except requests.exceptions.RequestException as e:
        print(f"请求失败: {str(e)}")
    except json.JSONDecodeError:
        print("响应解析失败")
    except KeyError:
        print("响应数据结构异常")

if __name__ == "__main__":
    search_github_vpn_projects()