from search import *
import os

quake_token = "4621ca88-58e5-4dc6-b91b-a38c711310c0"
global_url_set = set()

def read_lines(file_path):
    result = None
    with open(file_path, mode="r", encoding="utf-8") as fp:
        result = [url.strip() for url in fp.readlines() if len(url) != 0]
    return result

async def quake_plugin(rules:list):
    global global_url_set
    for rule in rules:
        global_url_set = global_url_set.union(quake_engine(quake_token).quake_get_service_Asset(rule))
    
async def check_active(url:str):
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36',
        'referer':'www.baidu.com',
        'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-encoding':'gzip, deflate, br, zstd',
        'accept-language':'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6'
    }

    if not url.startswith("http"):
        url = "http://" + url

    try:
        status = str(requests.get(url,headers=headers).status_code)
        if status.startswith("4") or status.startswith("5"): 
            return False
    except:
        return False

    return True


async def search_plugin(rule_path:str):
    quake_rules = set()
    bing_rules = set()

    rule_type = ""

    for rule in read_lines(rule_path):
        if rule.startswith("#:"):
            break
        elif rule.startswith("bing_:"):
            break
            #rule_type = "bing"
        elif rule.startswith("quake_:"):
            rule_type = "quake"
        elif len(rule.strip()):
            if rule_type == "quake":
                quake_rules.add(rule)
            elif rule_type == "bing":
                bing_rules.add(rule)

    #await bing_plugin(bing_rules)
    await quake_plugin(quake_rules)

async def send_redis():
    global global_url_set
    for url in global_url_set:
        if await check_active(url) == True:
            print("[quake_add] {}".format(url))
            os.system("redis-cli -h 11.93.228.50 -p 7654 -a yh --no-auth-warning SADD set_yh_cclist {}".format(url))


async def main():
    await search_plugin(os.path.join(os.path.dirname(__file__),"query_rule.txt"))
    await send_redis()

if __name__=="__main__":
    asyncio.run(main())
