import requests
import base64
import json
import yaml
import re
import os
import time
import datetime
from urllib.parse import urlparse
from concurrent.futures import ThreadPoolExecutor
import argparse

def decode_base64(data):
    """Base64解码并处理可能的填充问题"""
    # 移除非base64字符
    data = re.sub(r'[^a-zA-Z0-9+/=]', '', data)
    try:
        # 尝试标准解码
        decoded = base64.b64decode(data).decode('utf-8', errors='ignore')
        return decoded, None
    except:
        # 尝试添加填充后解码
        try:
            data += '=' * (-len(data) % 4)
            decoded = base64.b64decode(data).decode('utf-8', errors='ignore')
            return decoded, None
        except Exception as e:
            return None, f"Base64解码失败: {str(e)}"

def parse_v2rayn(content):
    """解析V2rayN订阅内容"""
    nodes = []
    decoded, error = decode_base64(content)
    if error or not decoded:
        return nodes, error
    
    # 分割每行节点配置
    for line in decoded.splitlines():
        line = line.strip()
        if not line:
            continue
            
        # 支持多种协议
        if line.startswith("vmess://"):
            try:
                # 提取vmess配置
                config_str = base64.b64decode(line[8:]).decode('utf-8', errors='ignore')
                config = json.loads(config_str)
                
                # 提取关键信息
                node = {
                    'type': 'vmess',
                    'protocol': 'VMess',
                    'address': config.get('add', ''),
                    'port': config.get('port', ''),
                    'id': config.get('id', ''),
                    'security': config.get('scy', 'auto'),
                    'network': config.get('net', 'tcp'),
                    'remarks': config.get('ps', ''),
                    'tls': config.get('tls', 'none'),
                    'sni': config.get('sni', ''),
                    'alpn': config.get('alpn', ''),
                    'udp': config.get('udp', True)
                }
                nodes.append(node)
            except Exception as e:
                pass
                
        elif line.startswith("ss://"):
            try:
                # 解析SS格式：ss://method:password@host:port#remark
                ss_data = line[5:]
                if "#" in ss_data:
                    ss_data, remark = ss_data.split("#", 1)
                    remark = base64.b64decode(remark).decode('utf-8', errors='ignore')
                else:
                    remark = ""
                
                # 解析基础部分
                if "@" in ss_data:
                    userinfo, server = ss_data.split("@", 1)
                    userinfo = base64.b64decode(userinfo).decode('utf-8', errors='ignore')
                    method, password = userinfo.split(":", 1)
                    host, port = server.split(":", 1)
                else:
                    # 完整base64格式
                    decoded = base64.b64decode(ss_data).decode('utf-8', errors='ignore')
                    if "@" in decoded:
                        userinfo, server = decoded.split("@", 1)
                        method, password = userinfo.split(":", 1)
                        host, port = server.split(":", 1)
                    else:
                        continue
                
                nodes.append({
                    'type': 'ss',
                    'protocol': 'Shadowsocks',
                    'address': host,
                    'port': port,
                    'method': method,
                    'password': password,
                    'remarks': remark
                })
            except:
                pass
                
        elif line.startswith("trojan://"):
            try:
                # 解析trojan格式：trojan://password@host:port?security=tls&sni=xxx#remark
                trojan_data = line[9:]
                if "#" in trojan_data:
                    trojan_data, remark = trojan_data.split("#", 1)
                    remark = base64.b64decode(remark).decode('utf-8', errors='ignore')
                else:
                    remark = ""
                
                # 分割密码和服务器
                if "@" in trojan_data:
                    password, server = trojan_data.split("@", 1)
                else:
                    password, server = trojan_data, ""
                
                # 分割服务器和参数
                if "?" in server:
                    server, params = server.split("?", 1)
                    params = dict(param.split("=") for param in params.split("&"))
                else:
                    params = {}
                
                host, port = server.split(":", 1)
                
                nodes.append({
                    'type': 'trojan',
                    'protocol': 'Trojan',
                    'address': host,
                    'port': port,
                    'password': password,
                    'remarks': remark,
                    'sni': params.get('sni', ''),
                    'alpn': params.get('alpn', ''),
                    'security': params.get('security', 'tls')
                })
            except:
                pass
                
    return nodes, None

def parse_clash(content):
    """解析Clash订阅内容"""
    try:
        # 尝试直接解析YAML
        config = yaml.safe_load(content)
        
        # 检查是否为Clash配置
        if 'proxies' not in config:
            return [], "缺少proxies字段，不是有效的Clash配置"
            
        nodes = []
        for proxy in config['proxies']:
            # 提取通用信息
            node = {
                'type': proxy.get('type', ''),
                'protocol': proxy.get('type', '').capitalize(),
                'address': proxy.get('server', ''),
                'port': proxy.get('port', ''),
                'remarks': proxy.get('name', '')
            }
            
            # 添加协议特定信息
            if proxy['type'] == 'vmess':
                node.update({
                    'uuid': proxy.get('uuid', ''),
                    'alterId': proxy.get('alterId', 0),
                    'cipher': proxy.get('cipher', 'auto'),
                    'udp': proxy.get('udp', False),
                    'tls': proxy.get('tls', False),
                    'sni': proxy.get('servername', ''),
                    'network': proxy.get('network', 'tcp')
                })
            elif proxy['type'] == 'ss':
                node.update({
                    'password': proxy.get('password', ''),
                    'cipher': proxy.get('cipher', ''),
                    'plugin': proxy.get('plugin', ''),
                    'plugin-opts': proxy.get('plugin-opts', {})
                })
            elif proxy['type'] == 'trojan':
                node.update({
                    'password': proxy.get('password', ''),
                    'sni': proxy.get('sni', ''),
                    'alpn': proxy.get('alpn', []),
                    'udp': proxy.get('udp', True)
                })
            elif proxy['type'] == 'vless':
                node.update({
                    'uuid': proxy.get('uuid', ''),
                    'flow': proxy.get('flow', ''),
                    'encryption': proxy.get('encryption', 'none'),
                    'tls': proxy.get('tls', False)
                })
            
            nodes.append(node)
        return nodes, None
    except Exception as e:
        return [], f"Clash解析失败: {str(e)}"

def parse_plain(content):
    """解析纯文本订阅"""
    nodes = []
    for line in content.splitlines():
        line = line.strip()
        if not line:
            continue
            
        # 尝试解析为URL
        if line.startswith(('http://', 'https://', 'vmess://', 'ss://', 'trojan://')):
            nodes.append({
                'type': 'url',
                'protocol': 'Direct URL',
                'address': line,
                'remarks': 'Direct subscription URL'
            })
        # 尝试解析为服务器列表
        elif re.match(r'^[\w\.-]+:\d+$', line):
            host, port = line.split(':', 1)
            nodes.append({
                'type': 'server',
                'protocol': 'TCP Server',
                'address': host,
                'port': port,
                'remarks': 'Plain server'
            })
    
    return nodes, None

def check_subscription(url):
    """检查单个订阅链接的有效性"""
    result = {
        'url': url,
        'type': 'unknown',
        'valid': False,
        'nodes': [],
        'error': '',
        'response_time': 0,
        'size': 0,
        'timestamp': datetime.datetime.now().isoformat()
    }
    
    try:
        start_time = time.time()
        
        # 发送HTTP请求
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        response = requests.get(url, headers=headers, timeout=15)
        response.raise_for_status()
        
        # 计算响应时间
        result['response_time'] = round((time.time() - start_time) * 1000, 2)
        result['size'] = len(response.content)
        content = response.text.strip()
        
        # 尝试解析为V2rayN
        nodes, error = parse_v2rayn(content)
        if nodes:
            result['type'] = 'v2rayn'
            result['valid'] = True
            result['nodes'] = nodes
            return result
        
        # 尝试解析为Clash
        nodes, error = parse_clash(content)
        if nodes:
            result['type'] = 'clash'
            result['valid'] = True
            result['nodes'] = nodes
            return result
            
        # 尝试解析纯文本
        nodes, error = parse_plain(content)
        if nodes:
            result['type'] = 'plain'
            result['valid'] = True
            result['nodes'] = nodes
            return result
            
        result['error'] = "无法识别的订阅格式"
    except requests.exceptions.RequestException as e:
        result['error'] = f"请求失败: {str(e)}"
    except Exception as e:
        result['error'] = f"处理错误: {str(e)}"
    
    return result

def extract_all_nodes(results):
    """从所有结果中提取所有节点"""
    all_nodes = []
    for res in results:
        if res['valid']:
            for node in res['nodes']:
                # 添加订阅源信息
                node['source_url'] = res['url']
                node['source_type'] = res['type']
                node['response_time'] = res['response_time']
                node['subscription_valid'] = True
                node['subscription_timestamp'] = res['timestamp']
                all_nodes.append(node)
    return all_nodes

def generate_full_report(results, all_nodes, output_file):
    """生成完整的报告文件"""
    try:
        # 创建输出目录
        os.makedirs(os.path.dirname(output_file), exist_ok=True)
        
        with open(output_file, 'w', encoding='utf-8') as f:
            # 报告头信息
            f.write("=" * 80 + "\n")
            f.write(f"VPN订阅批量验证报告\n")
            f.write(f"生成时间: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"订阅总数: {len(results)}\n")
            f.write("=" * 80 + "\n\n")
            
            # 第一部分：订阅验证结果汇总
            f.write("一、订阅验证结果汇总\n")
            f.write("-" * 80 + "\n")
            f.write(f"{'订阅链接':<50} | {'类型':<8} | {'状态':<6} | {'节点数':<6} | {'响应时间(ms)':<12} | {'错误信息'}\n")
            f.write("-" * 80 + "\n")
            
            valid_count = 0
            total_nodes = 0
            for res in results:
                status = '有效' if res['valid'] else '无效'
                node_count = len(res['nodes'])
                total_nodes += node_count
                if res['valid']:
                    valid_count += 1
                
                f.write(f"{res['url']:<50} | {res['type']:<8} | {status:<6} | {node_count:<6} | {res['response_time']:<12} | {res.get('error', '')}\n")
            
            f.write("-" * 80 + "\n")
            f.write(f"有效订阅: {valid_count}/{len(results)} ({valid_count/len(results)*100:.1f}%)\n")
            f.write(f"总节点数: {total_nodes}\n")
            f.write("=" * 80 + "\n\n")
            
            # 第二部分：详细订阅信息
            f.write("二、订阅详细信息\n")
            f.write("=" * 80 + "\n")
            for i, res in enumerate(results, 1):
                f.write(f"\n[{i}/{len(results)}] 订阅链接: {res['url']}\n")
                f.write(f"  验证时间: {res['timestamp']}\n")
                f.write(f"  订阅类型: {res['type']}\n")
                f.write(f"  验证状态: {'有效' if res['valid'] else '无效'}\n")
                f.write(f"  响应时间: {res['response_time']} ms\n")
                f.write(f"  数据大小: {res['size']} 字节\n")
                
                if res['valid']:
                    f.write(f"  节点数量: {len(res['nodes'])}\n")
                else:
                    f.write(f"  错误信息: {res.get('error', '未知错误')}\n")
                
                # 输出节点详情
                if res['nodes']:
                    f.write("\n  节点列表:\n")
                    f.write("  " + "-" * 78 + "\n")
                    for j, node in enumerate(res['nodes'], 1):
                        f.write(f"  {j}. 类型: {node.get('protocol', node.get('type', 'N/A'))}\n")
                        f.write(f"     地址: {node.get('address', '')}\n")
                        if 'port' in node:
                            f.write(f"     端口: {node.get('port', '')}\n")
                        if 'remarks' in node and node['remarks']:
                            f.write(f"     备注: {node['remarks']}\n")
                        if 'password' in node:
                            f.write(f"     密码: {node['password']}\n")
                        if 'id' in node or 'uuid' in node:
                            f.write(f"     UUID: {node.get('id', node.get('uuid', ''))}\n")
                        if 'method' in node:
                            f.write(f"     加密: {node['method']}\n")
                        if 'security' in node:
                            f.write(f"     安全: {node['security']}\n")
                        if 'network' in node:
                            f.write(f"     网络: {node['network']}\n")
                        f.write("  " + "-" * 78 + "\n")
                
                f.write("\n" + "=" * 80 + "\n")
            
            # 第三部分：所有节点汇总
            f.write("\n三、所有节点汇总\n")
            f.write("=" * 80 + "\n")
            f.write(f"总节点数: {len(all_nodes)}\n")
            f.write("=" * 80 + "\n")
            
            # 节点类型分布
            node_types = {}
            for node in all_nodes:
                t = node.get('type', 'unknown')
                node_types[t] = node_types.get(t, 0) + 1
            
            f.write("\n节点类型分布:\n")
            for t, count in node_types.items():
                f.write(f"  {t.upper():<10}: {count} ({count/len(all_nodes)*100:.1f}%)\n")
            
            # 节点详情列表
            f.write("\n节点详情列表:\n")
            f.write("-" * 80 + "\n")
            for i, node in enumerate(all_nodes, 1):
                f.write(f"{i}. 协议: {node.get('protocol', node.get('type', 'N/A'))}\n")
                f.write(f"   地址: {node.get('address', '')}\n")
                f.write(f"   端口: {node.get('port', '')}\n")
                f.write(f"   来源: {node.get('source_url', '')} [{node.get('source_type', '')}]\n")
                if 'remarks' in node and node['remarks']:
                    f.write(f"   备注: {node['remarks']}\n")
                f.write("-" * 80 + "\n")
            
            # 第四部分：统计报告
            f.write("\n四、统计报告\n")
            f.write("=" * 80 + "\n")
            f.write(f"订阅总数: {len(results)}\n")
            f.write(f"有效订阅: {valid_count} ({valid_count/len(results)*100:.1f}%)\n")
            f.write(f"无效订阅: {len(results) - valid_count}\n")
            f.write(f"总节点数: {len(all_nodes)}\n")
            f.write(f"平均节点数/订阅: {len(all_nodes)/valid_count if valid_count > 0 else 0:.1f}\n")
            f.write(f"平均响应时间: {sum(r['response_time'] for r in results)/len(results):.2f} ms\n")
            f.write("\n节点类型统计:\n")
            for t, count in node_types.items():
                f.write(f"  {t.upper():<10}: {count} ({count/len(all_nodes)*100:.1f}%)\n")
            
            f.write("\n" + "=" * 80 + "\n")
            f.write("报告生成完成\n")
            f.write("=" * 80 + "\n")
            
        return True
    except Exception as e:
        print(f"生成报告失败: {str(e)}")
        return False

def main():
    parser = argparse.ArgumentParser(description='VPN订阅链接批量验证与节点提取工具')
    parser.add_argument('file', help='包含订阅链接的文件路径')
    parser.add_argument('-t', '--threads', type=int, default=10, help='并发线程数 (默认: 10)')
    parser.add_argument('-o', '--output', required=True, help='完整报告输出文件')
    parser.add_argument('--dedup', action='store_true', help='去重重复节点')
    parser.add_argument('--sort', choices=['address', 'port', 'type'], default='address',
                        help='排序方式 (address/port/type, 默认: address)')
    args = parser.parse_args()

    # 读取订阅链接
    try:
        with open(args.file, 'r') as f:
            urls = [line.strip() for line in f if line.strip()]
    except FileNotFoundError:
        print(f"错误: 文件 {args.file} 不存在")
        return
    except Exception as e:
        print(f"读取文件错误: {str(e)}")
        return

    if not urls:
        print("错误: 文件为空或没有有效的URL")
        return

    print(f"开始验证 {len(urls)} 个订阅链接, 使用 {args.threads} 线程...")
    print(f"报告将保存到: {args.output}")

    # 使用线程池并发验证
    results = []
    with ThreadPoolExecutor(max_workers=args.threads) as executor:
        futures = [executor.submit(check_subscription, url) for url in urls]
        for i, future in enumerate(futures, 1):
            try:
                result = future.result()
                results.append(result)
                status = '有效' if result['valid'] else '无效'
                nodes_count = len(result['nodes'])
                print(f"[{i}/{len(urls)}] {result['url']} - {status} ({nodes_count}节点)")
            except Exception as e:
                print(f"[{i}/{len(urls)}] 处理异常: {str(e)}")

    # 提取所有节点
    all_nodes = extract_all_nodes(results)
    
    # 去重处理
    if args.dedup:
        seen = set()
        dedup_nodes = []
        for node in all_nodes:
            # 基于地址、端口和类型创建唯一标识
            identifier = (node.get('address', ''), str(node.get('port', '')), node.get('type', ''))
            if identifier not in seen:
                seen.add(identifier)
                dedup_nodes.append(node)
        all_nodes = dedup_nodes
        print(f"去重后节点数: {len(all_nodes)} (原始: {len(dedup_nodes) + len(seen)})")

    # 排序处理
    if args.sort == 'port':
        all_nodes.sort(key=lambda x: int(x.get('port', 0)))
    elif args.sort == 'type':
        all_nodes.sort(key=lambda x: x.get('type', ''))
    else:  # address
        all_nodes.sort(key=lambda x: x.get('address', ''))

    # 生成完整报告
    if generate_full_report(results, all_nodes, args.output):
        print(f"\n完整报告已保存到: {args.output}")
        print(f"包含: {len(results)} 个订阅验证结果, {len(all_nodes)} 个节点")
    else:
        print("\n报告生成失败")

    # 控制台统计摘要
    valid_sub = sum(1 for res in results if res['valid'])
    total_nodes = len(all_nodes)
    node_types = {}
    for node in all_nodes:
        t = node.get('type', 'unknown')
        node_types[t] = node_types.get(t, 0) + 1
    
    print("\n统计摘要:")
    print(f"订阅总数: {len(urls)}")
    print(f"有效订阅: {valid_sub} ({valid_sub/len(urls)*100:.1f}%)")
    print(f"无效订阅: {len(urls) - valid_sub}")
    print(f"总节点数: {total_nodes}")
    print("节点类型分布:")
    for t, count in node_types.items():
        print(f"  {t.upper():<10}: {count} ({count/total_nodes*100:.1f}%)")

if __name__ == "__main__":
    main()