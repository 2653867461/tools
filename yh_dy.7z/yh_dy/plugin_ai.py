import requests
import openai 

ai_config = {
    "qihoo_ai":{
        "url":"https://api.360.cn/v1",
        "key":"fk3374890606.SHFC4WxoXxZmwr_kTGoVkzivkYB6pyNd866479fc",
        "models":["deepseek-chat-v3"]
    }
}


class ai_engine:
    def __init__(self,url:str,key:str,modules:list):
        self.client = openai.OpenAI(api_key=key,base_url=url)
        self.modules = modules
        self.history = list()

    def chat(self,history:bool=False):

        response = self.client.chat.completions.create(
            messages=[
                {'role': 'user', 'content': "1+1等于几？帮我说列出详细步骤。"},
            ],
            model='gpt-3.5-turbo',stream=True)

        return response.choices[0].message.content