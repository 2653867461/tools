

import re
import requests
import hashlib
import asyncio
import socket
import socks

from stem import Signal
from stem.control import Controller

qihoo_proxy = {'http': 'http://10.16.13.18:8080', 'https': 'http://10.16.13.18:8080'}
default_proxy = None

class OkEngine:
    def __init__(self):
        self.locker = asyncio.Lock()
        self.times = 0

    async def add_task(self):
        await self.locker.acquire()
        self.times += 1
        self.locker.release()


    async def sub_task(self):
        await self.locker.acquire()
        self.times -= 1
        self.locker.release()

    async def get_task(self):
        await self.locker.acquire()
        result = self.times
        self.locker.release()
        return result

class ResultSet:
    def __init__(self):
        self.src2down_result = dict()
        self.down2md5_result = dict()
        self.locker = asyncio.Lock()

    async def add_src2down_result(self,src:str,down_url:str):
        await self.locker.acquire()

        if src not in self.src2down_result:
            self.src2down_result[src] = set()
        self.src2down_result[src].add(down_url)

        self.locker.release()

    async def add_down2md5_result(self,down_url:str,md5:str):
        await self.locker.acquire()

        if down_url not in self.down2md5_result:
            self.down2md5_result[down_url] = set()
        self.down2md5_result[down_url].add(md5)

        self.locker.release()


def calculate_file_hash(file_path, hash_algo='md5'):
    """计算文件的哈希值"""
    hash_func = hashlib.new(hash_algo)
    try:
        with open(file_path, 'rb') as f:
            while chunk := f.read(8192):
                hash_func.update(chunk)
        return hash_func.hexdigest()
    except Exception as e:
        print(f"无法读取文件 {file_path}: {e}")
        return None

def read_lines(file_path):
    result = None
    with open(file_path, mode="r", encoding="utf-8") as fp:
        result = [url.strip() for url in fp.readlines() if len(url) != 0]
    return result


def extract_domain(urls):
    domain_pattern = r"https?://([a-zA-Z0-9.-]+)"

    if type(urls) == str:
        return re.find(domain_pattern, urls)
    else:
        return [re.find(domain_pattern, url) for url in urls]


def check_active_by_head(url):
    if (requests.head("http://" + url, allow_redirects=True, timeout=2).status_code< 400):
        return False
    return True

def enable_v2ray_proxy():
    global default_proxy
    socks.set_default_proxy(socks.SOCKS5, "127.0.0.1", 10808)
    socket.socket = socks.socksocket
    default_proxy = {
        "socks5": "socks5://127.0.0.1:10808",
        "http": "http://127.0.0.1:10809",
    }

def enable_qihoo_proxy():
    global default_proxy
    socks.set_default_proxy(socks.HTTP, "10.16.13.18", 8080)
    socket.socket = socks.socksocket
    default_proxy = {
        "http": "http://10.16.13.18:8080",
    }


def enable_tor_proxy():
    global default_proxy
    socks.set_default_proxy(socks.SOCKS5, "127.0.0.1", 9050)
    socket.socket = socks.socksocket
    default_proxy = {
        "socks5": "socks5://127.0.0.1:9050",
        "http": "socks5://127.0.0.1:9050",
    }


def tor_switch_proxy():
    with Controller.from_port(port=9051) as controller:
        controller.authenticate()
        controller.signal(Signal.NEWNYM)


