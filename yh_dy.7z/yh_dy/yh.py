import logging
import os

from cnocr import CnOcr
from urllib.parse import urlparse
from playwright.async_api import async_playwright,Page,Download
import asyncio
import redis

from search import *
from util import *

os.chdir(os.path.dirname(os.path.abspath(__file__)))

#重定向运行日志
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

# 文件输出
file_handler = logging.FileHandler("./SpliderBrowser.log", mode="w+")
file_handler.setFormatter(logging.Formatter("%(asctime)s - %(filename)s[line:%(lineno)d] - %(levelname)s: %(message)s"))
logger.addHandler(file_handler)

# 控制台输出
console_handler = logging.StreamHandler()
console_handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s: %(message)s"))
logger.addHandler(console_handler)

DEFAULT_CONFIG = {
    'concurrency': 4,                                                           #同时打开页面数
    'headless': True,                                                           #启用GUI
    'navigation_timeout': 30000,                                                #等待超时时间
    'screenshot_path': './screenshots',                                         #页面快照保存路径
    'file_save_path':"./files",                                                 #文件保存路径 
    'result_file_path':"./result.txt",                                          #保存结果文件
    'max_download':10,                                                          #同时下载文件数
    "dealy_time": 0.2,                                                          #点击间等待时间                 
    'cnocr_config':{                                                            #OCR设置   
        "rec_model_name":'densenet_lite_136-gru',
        "det_model_name":"db_shufflenet_v2_small",
        "det_more_configs":{
            "rotated_bbox":False
        }
    },
    'quake_confg':{
        "quake_token":"4621ca88-58e5-4dc6-b91b-a38c711310c0",                   #quake默认Token
        "query_rule_path":"./query_rule.txt",                                   #查询规则文件
    }
}

if os.path.exists(DEFAULT_CONFIG["file_save_path"]) == False:
    os.mkdir(DEFAULT_CONFIG["file_save_path"])

if os.path.exists(DEFAULT_CONFIG["screenshot_path"]) == False:  
    os.mkdir(DEFAULT_CONFIG["screenshot_path"])

gResultSet = ResultSet()
gOkEngine = OkEngine()

class PageHandler:
    def __init__(self, page: Page,url_queue: asyncio.Queue,config: dict):
        self.page = page
        self.url_queue = url_queue
        self.config = config
        self.cur_url = None

    '''
    监控页面下载事件：
    dwonload_info.page.url: 页面地址
    dwonload_info.url: 下载地址
    '''
    async def _download_mitmproxy(self,dwonload_info:Download):
        md5 = None
        await gResultSet.add_src2down_result(dwonload_info.page.url,dwonload_info.url)
        logging.error(f"开始下载文件 页面地址:{dwonload_info.page.url} 下载地址:{dwonload_info.url} 文件名:{dwonload_info.suggested_filename}")
        await gOkEngine.add_task()

        try:

            file_path = await dwonload_info.path()
            if os.path.exists(file_path):
                md5 = calculate_file_hash(file_path)
                if md5 != None:
                    if os.path.exists(os.path.join(self.config["file_save_path"],md5)) == False:
                        os.rename(file_path,os.path.join(self.config["file_save_path"],md5))
                    await gResultSet.add_down2md5_result(dwonload_info.url,md5)
                    #logging.error(f"下载地址: {dwonload_info.url} 文件MD5: {md5}")

        except Exception as e:
            pass
            #logging.error(f"下载处理错误: {dwonload_info.page.url} - {str(e)}")

        finally:
            logging.error(f"下载文件结束 页面地址:{dwonload_info.page.url} 下载地址:{dwonload_info.url} 文件名:{dwonload_info.suggested_filename } 文件MD5:{md5}")
            await gOkEngine.sub_task()

    '''
    关闭新打开的页面
    '''
    async def _page_mitmproxy(self,page_info:Page):
        await page_info.clsoe()

    async def _goto_page(self,url:str):
        # 导航到页面
        try:
            if not url.startswith("http"):
                url = "http://" + url

            await asyncio.sleep(0.5)
            response = await self.page.goto(url, wait_until="domcontentloaded",timeout=self.config['navigation_timeout'])
            await asyncio.sleep(0.5)
            
            if response and response.ok:
                return True
            
        except Exception as e:
            pass
            #logging.error(f"导航到指定页面错误: {url} - {str(e)}")
        return False

    async def process_page(self):
        self.page.on("download",self._download_mitmproxy)
        self.page.on("page",self._page_mitmproxy)

        #先等待redis协程获取下载数据
        await asyncio.sleep(15)

        """主处理循环"""
        while not self.url_queue.empty():

            #同时最多下载max_download个文件
            while gOkEngine.get_task() > self.config["max_download"] :
                await asyncio.sleep(2)

            url = await self.url_queue.get()
            try:
                if await self._goto_page(url):
                    self.cur_url = url
                    #logging.error(f"处理页面: {url}")

                    await self._handle_dynamic_content_by_ocr()

            except Exception as e:
                pass
                #logging.error(f"处理页面错误: {url} - {str(e)}")
            finally:
                self.url_queue.task_done()

    async def _ocr_img(self):
        result = []
        try:
            img_path = os.path.join(self.config["screenshot_path"],urlparse(self.page.url).hostname.replace(".","_").replace("/","_") +".png")
            await self.page.screenshot(path=img_path)
            ocr = CnOcr(**self.config["cnocr_config"])
            result = ocr.ocr(img_path) 
        except Exception as e:
            pass#logging.error(f"OCR处理错误: {self.page.url} - {str(e)}")
        return result

    async def _click_element_by_positive(self,pos_x,pos_y):
        try:
            element_handle = await self.page.evaluate_handle("""([xPos, yPos]) => document.elementFromPoint(xPos, yPos)""",[pos_x, pos_y])
            await asyncio.sleep(self.config["dealy_time"])
            await element_handle.as_element().click()
            await asyncio.sleep(self.config["dealy_time"])
        except Exception as e:
            pass#logging.error(f"点击处理错误: {self.page.url} - {str(e)}")

    async def _handle_dynamic_content_by_ocr(self):
        for ocr_item in await self._ocr_img():
            if ocr_item["text"].find("下载") != -1 or ocr_item["text"].lower().find("download") != -1:
                await self._click_element_by_positive((ocr_item["position"][0][0] + ocr_item["position"][2][0])/2,(ocr_item["position"][0][1] + ocr_item["position"][2][1])/2)
                if self.cur_url != self.page.url and not await self._goto_page(self.cur_url):
                    pass#logging.error(f"页面未知跳转错误: {self.page.url}")
                    break

class BrowserManager:
    def __init__(self, config: dict = DEFAULT_CONFIG):
        self.config = config
        self.pages = []
        self.tasks = []
        self.url_queue = asyncio.Queue(1000)

    async def quake_plugin(self,rules:list):
        result = set()
        for rule in rules:
            result = result.union(quake_engine(self.config["quake_confg"]["quake_token"]).quake_get_service_Asset(rule))
        for url in result:
            await self.url_queue.put(url)

    async def bing_plugin(self,rules:list):
        result = set()
        for rule in rules:
            for url,desc in await bing_search(rule.split("bing_",1)[1],2000).items():
                if url not in result:
                    result.add(url)
                    await self.url_queue.put(url)
        
    async def search_plugin(self,rule_path:str):
        quake_rules = set()
        bing_rules = set()

        rule_type = ""

        for rule in read_lines(rule_path):
            if rule.startswith("#:"):
                break
            elif rule.startswith("bing_:"):
                rule_type = "bing"
            elif rule.startswith("quake_:"):
                rule_type = "quake"
            elif len(rule.strip()):
                if rule_type == "quake":
                    quake_rules.add(rule)
                elif rule_type == "bing":
                    bing_rules.add(rule)

        
        await self.bing_plugin(bing_rules)
        await self.quake_plugin(quake_rules)

    async def read_c2_from_file(self,file_path):
        for url in read_lines(file_path):
            await self.url_queue.put(url)

    #从redis获取数据协程
    async def read_redis(self):
        redis_client = redis.StrictRedis(host='11.93.228.50', port=7654, password="yh")
        while redis_client.llen("yh_cclist"):
            for c2 in redis_client.lrange('yh_cclist', 0, 100):
                await self.url_queue.put(str(c2))            

    async def start(self):
        """启动浏览器实例"""

        #await self.read_c2_from_file(r"C:\Users\qw265\Downloads\yh_dy\c2.txt")
        #await self.search_plugin(self.config["quake_confg"]["query_rule_path"])
        #enable_qihoo_proxy()
        #logging.error("处理规则完成 任务总数: {}".format(self.url_queue.qsize()))

        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=self.config['headless'],args=['--disable-infobars','--start-maximized','--disable-blink-features=AutomationControlled','--ignore-certificate-errors'])
            context = await browser.new_context()
            
            for _ in range(self.config['concurrency']):
                page = await context.new_page()
                handler = PageHandler(page=page,url_queue=self.url_queue,config=self.config)
                self.tasks.append(asyncio.create_task(handler.process_page()))

            self.tasks.append(asyncio.create_task(self.read_redis()))
            
            await asyncio.gather(*self.tasks)

            logging.error("等待url队列处理完成")
            await self.url_queue.join()

            logging.error("等待下载任务处理完成")
            while True:
                await asyncio.sleep(2)
                if await gOkEngine.get_task() == 0:
                    break
            
            logging.error("记录结果")
            try:
                pass
            finally:
                with open(self.config["result_file_path"], "w+", encoding="utf-8") as fp:
                    for src,downs in gResultSet.src2down_result.items():
                        for down in downs:
                            if gResultSet.down2md5_result.get(down) != None:
                                for md5 in gResultSet.down2md5_result[down]:
                                    fp.write(f"{src} {down} {md5}\n")    
            await browser.close()

asyncio.run(BrowserManager().start())
